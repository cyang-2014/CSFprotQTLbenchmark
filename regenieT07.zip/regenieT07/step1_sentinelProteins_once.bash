#!/bin/bash
# Add covariates to command line argument, comma separated, no spaces, case sensitive; add any additional arguments
# Create file named analytes.txt with list of phenotypes to be tested, one per line, ending with a blank line
echo Running single variant analysis
genodir=/03-DryLab/04-Analyses/2021_Multi-Omics_CC/2022_MultiTissue-MultiOmics_Chengran/t16_benchmarkQTL/run00_genoCSFlongs/st04_prune/
filename=$(ls $genodir | egrep 'CSFbenchmarkFeb2024afterPrune.bed' | awk '{print $1}' FS=.)
# grab name for PLINK input binary files
echo $filename

phenodir=/03-DryLab/04-Analyses/2021_Multi-Omics_CC/2022_MultiTissue-MultiOmics_Chengran/t16_benchmarkQTL/run02_CSFlongsINVR/d00_input/
pheno=$(ls $phenodir | egrep 'f05_EURgeno_pheno_2249pariticipants_2999somamers_sentinel.txt' | awk '{print $1}')
# grab file name for file with phenotype info
echo $pheno

covardir=/03-DryLab/04-Analyses/2021_Multi-Omics_CC/2022_MultiTissue-MultiOmics_Chengran/t16_benchmarkQTL/run02_CSFlongsINVR/d00_input/
covarFILE=$(ls $covardir | egrep 'f04_EURgeno_covar_2249pariticipants_10gPC60peer.txt' | awk '{print $1}')
# grab file name for file with covariate info
echo $covarFILE


outdirS1=/03-DryLab/04-Analyses/2021_Multi-Omics_CC/2022_MultiTissue-MultiOmics_Chengran/t16_benchmarkQTL/run02_CSFlongsINVR/d07_regenieOUTwiPEER/t02_sentinelVars/outputS1
mkdir $outdirS1


#################################
## to be compatible for the parallel command
#################################

## step-1: Run regenie for each analyte using the covariates from argument and any additional arguments

#analyte=$1
#echo $analyte

regenie \
--step 1 \
--bed $genodir/$filename \
--covarFile "$covardir/$covarFILE" \
--phenoFile "$phenodir/$pheno" \
--bsize 1000 \
--lowmem \
--lowmem-prefix $outdirS1/T07_WU_CSF_EUR \
--threads 20 \
--out "$outdirS1/T07_WU_CSF_EUR"
