#!/bin/bash
# Add covariates to command line argument, comma separated, no spaces, case sensitive; add any additional arguments
# Create file named analytes.txt with list of phenotypes to be tested, one per line, ending with a blank line

echo Running single variant analysis

genodir=/03-DryLab/04-Analyses/2021_Multi-Omics_CC/2022_MultiTissue-MultiOmics_Chengran/t16_benchmarkQTL/run00_genoCSFlongs/st01_extractFEB2024/
filename=$(ls $genodir | egrep 'CSF_pQTL_benchmark_FEB2024_arrayOptimized_final.bed' | awk '{print $1}' FS=.)
# grab name for PLINK input binary files
echo $filename

phenodir=/03-DryLab/04-Analyses/2021_Multi-Omics_CC/2022_MultiTissue-MultiOmics_Chengran/t16_benchmarkQTL/run02_CSFlongsINVR/d00_input/
pheno=$(ls $phenodir | egrep 'f05_EURgeno_pheno_2249pariticipants_2999somamers_sentinel.txt' | awk '{print $1}')
# grab file name for file with phenotype info
echo $pheno

covardir=/03-DryLab/04-Analyses/2021_Multi-Omics_CC/2022_MultiTissue-MultiOmics_Chengran/t16_benchmarkQTL/run02_CSFlongsINVR/d00_input/
covarFILE=$(ls $covardir | egrep 'f04_EURgeno_covar_2249pariticipants_10gPC60peer.txt' | awk '{print $1}')
# grab file name for file with covariate info
echo $covarFILE


outdirS1=/03-DryLab/04-Analyses/2021_Multi-Omics_CC/2022_MultiTissue-MultiOmics_Chengran/t16_benchmarkQTL/run02_CSFlongsINVR/d07_regenieOUTwiPEER/t02_sentinelVars/outputS1

outdirS2=/03-DryLab/04-Analyses/2021_Multi-Omics_CC/2022_MultiTissue-MultiOmics_Chengran/t16_benchmarkQTL/run02_CSFlongsINVR/d07_regenieOUTwiPEER/t02_sentinelVars/outputS2
mkdir $outdirS2


sentinelVariantFile=/03-DryLab/04-Analyses/2021_Multi-Omics_CC/2022_MultiTissue-MultiOmics_Chengran/t16_benchmarkQTL/run00_genoCSFlongs/f06b_union_keepUniqueProtVarBlock_varNameOnly.csv


#################################
## to be compatible for the parallel command
#################################

## step-2: Run regenie for each analyte using the covariates from argument and any additional arguments

#analyte=$1
#echo $analyte


regenie \
--step 2 \
--bed $genodir/$filename \
--covarFile "$covardir/$covarFILE" \
--phenoFile "$phenodir/$pheno" \
--extract $sentinelVariantFile \
--bsize 1000 \
--threads 30 \
--pred "$outdirS1/T07_WU_CSF_EUR_pred.list" \
--gz \
--out "$outdirS2/T07_WU_CSF_EUR"

